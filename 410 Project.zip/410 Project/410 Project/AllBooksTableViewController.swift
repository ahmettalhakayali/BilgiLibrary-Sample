//
//  MainFavTableViewController.swift
//  410 Project
//
//  Created by İbrahim KARALI on 18.05.2018.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit

class AllBooksTableViewController: UITableViewController {

    var book = Book.init()
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return book.bookList.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! AllBooksTableViewCell

        let myBookNames = book.bookKeys
        let myBookList = book.bookList
        
        cell.bookAuthor.text = myBookList[myBookNames[indexPath.row]]?.author
        cell.bookName.text  = myBookList[myBookNames[indexPath.row]]?.name
        cell.bookKind.text  = myBookList[myBookNames[indexPath.row]]?.kind
        cell.bookPrice.text  = String(describing: myBookList[myBookNames[indexPath.row]]!.price)
        cell.bookImage.image = myBookList[myBookNames[indexPath.row]]?.bookCover

        return cell
    }
 



}
