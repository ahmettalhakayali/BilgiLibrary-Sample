//
//  FavoritesTableViewController.swift
//  410 Project
//
//  Created by İbrahim KARALI on 19.05.2018.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit
import CoreData

class FavoritesTableViewController: UITableViewController {
    
    let book = Book.init()
    var books:[Book] = []

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
            print("did apear worked")
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            
            let context = appDelegate.persistentContainer.viewContext
            
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
            
            do {
                let results = try context.fetch(request)
                
                if results.count > 0 {
                    for result in results as! [NSManagedObject] {
                        let filter = result.value(forKey: "favorite") as! String
                        books = book.filter(byKind: filter)
                    }
                }
                tableView.reloadData()
                
            } catch  {
                print(" favtab error")
            }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return books.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "favCell", for: indexPath) as! FavoritesTableViewCell

        cell.bookImage.image = books[indexPath.row].bookCover
        cell.bookAuthor.text = books[indexPath.row].author
        cell.bookName.text = books[indexPath.row].name
        cell.bookKind.text = books[indexPath.row].kind
        cell.bookPrice.text = String(books[indexPath.row].price)
        

        return cell
    }
 

}
