//
//  FavoriteTableViewController.swift
//  410 Project
//
//  Created by İbrahim KARALI on 17.05.2018.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit
import CoreData

class SelectFavTableViewController: UITableViewController {
    var favorite = ""
    
    var isSelected:[Bool] = []
    var whichKind: [String] = []
    let kindList = ["Sci-Fi", "Fantastic", "History", "Science", "Romance", "Food"]

    
    @IBAction func finish(_ sender: UIBarButtonItem) {
        
        for item in whichKind {
            favorite = "\(favorite),\(item)"
        }
        
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        
        do {
            let results = try context.fetch(request)
            
            if results.count > 0 {
                print(results.count)
                
                for result in results as! [NSManagedObject] {
                    
                    result.setValue(favorite, forKey: "favorite")
                    
                    do {
                        try context.save()
                        performSegue(withIdentifier: "loginningIn", sender: self)
                        
                    } catch {
                        print("Update username save failed")
                    }
                }
                
            }
            
        } catch {
            print("error")
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        if section == 0 {
            return 1
        } else {
            return kindList.count
        }
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "favCell", for: indexPath) as! SelectFavTableViewCell
            
            cell.titleLabel.text = "Select Favorite Kind"
            
            
            return cell
            
        } else {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "favCell", for: indexPath)
            
            cell.textLabel?.text = kindList[indexPath.row]
            isSelected.append(false)
            
            return cell
        }
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        
        if isSelected[indexPath.row] {
            isSelected[indexPath.row] = false
            cell?.accessoryType = UITableViewCellAccessoryType.none
            whichKind.remove(at: whichKind.index(of: kindList[indexPath.row])!)
            
        } else {
            isSelected[indexPath.row] = true
            cell?.accessoryType = UITableViewCellAccessoryType.checkmark
            whichKind.append(kindList[indexPath.row])
        }
        
    }

}
