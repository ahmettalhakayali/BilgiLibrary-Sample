//
//  ViewController.swift
//  410 Project
//
//  Created by İbrahim KARALI on 14.05.2018.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDelegate {
    @IBOutlet var titleLabel: UILabel!
    
    @IBOutlet var nameText: UITextField!
    @IBOutlet var email: UITextField!
    @IBOutlet var phoneNumber: UITextField!
    @IBOutlet var loginButton: UIButton!
    @IBOutlet var birthday: UIDatePicker!
    @IBOutlet var address: UITextView!
    

    var Array = ["Action" , "Fantastic" , "History"]
    var isLogedin = false
    @IBAction func login(_ sender: UIButton) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext

        if isLogedin {
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
            
            
            do {
                let results = try context.fetch(request)
                
                if results.count > 0 {
                    print(results.count)

                    for result in results as! [NSManagedObject] {
                        
                        result.setValue(nameText.text, forKey: "name")
                        result.setValue(email.text, forKey: "email")
                        result.setValue(phoneNumber.text, forKey: "phoneNumber")
                        result.setValue(birthday.date, forKey: "date")
                        result.setValue(address.text, forKey: "address")
                        result.setValue("", forKey: "books")
                        
                        do {
                            try context.save()
                            performSegue(withIdentifier: "loggedIn", sender: self)
                            
                        } catch {
                            print("Update username save failed")
                        }
                    }
                    
                    
                }
                
            } catch {
                print("error")
            }
            
            
        } else {
            let newValue = NSEntityDescription.insertNewObject(forEntityName: "Users", into: context)
            
            newValue.setValue(nameText.text, forKey: "name")
            newValue.setValue(email.text, forKey: "email")
            newValue.setValue(phoneNumber.text, forKey: "phoneNumber")
            newValue.setValue(birthday.date, forKey: "date")
            newValue.setValue(address.text, forKey: "address")
            newValue.setValue("", forKey: "books")

            

            do {
                try context.save()
                performSegue(withIdentifier: "selectFav", sender: self)
                isLogedin = true

            } catch {
                print("errorroror")
            }
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {

        self.navigationItem.hidesBackButton = true
        self.navigationController?.isNavigationBarHidden = true
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate // UIApplication.shared().delegate as! AppDelegate is now UIApplication.shared.delegate as! AppDelegate
        
        
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        
        request.returnsObjectsAsFaults = false
        
        do {
            let results = try context.fetch(request)
            
            for result in results as! [NSManagedObject] {
                if (result.value(forKey: "name") as? String) != nil {
                    performSegue(withIdentifier: "loggedIn", sender: self)
                    print(result.value(forKey: "name")!)
                }
                
            }
            
        } catch  {
            print("didload error")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return Array[row]
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return Array.count
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }*/
    
   
    
    
}



