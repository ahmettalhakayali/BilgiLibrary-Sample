//
//  MainTableViewCell.swift
//  410 Project
//
//  Created by İbrahim KARALI on 18.05.2018.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit
import CoreData

class AllBooksTableViewCell: UITableViewCell {

    @IBOutlet var bookImage: UIImageView!
    
    @IBOutlet var bookName: UILabel!
    @IBOutlet var bookKind: UILabel!
    @IBOutlet var bookAuthor: UILabel!
    @IBOutlet var bookPrice: UILabel!
    
    @IBOutlet var buyButton: UIButton!
    @IBAction func buy(_ sender: UIButton) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        
        do {
            let results = try context.fetch(request)
            
            if results.count > 0 {
                for result in results as! [NSManagedObject] {
                    if var temp = result.value(forKey: "books") as! String? {
                        if let tempName = bookName.text as String? {
                            temp = "\(temp),\(tempName)"
                            result.setValue(temp, forKey: "books")
                            print(temp)
                            buyButton.setTitle("Added", for: [])
                            buyButton.isEnabled = false
                        }
                    }
                    
                }
            }
        } catch  {
            print("FavoritesCell error")
        }
        
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
