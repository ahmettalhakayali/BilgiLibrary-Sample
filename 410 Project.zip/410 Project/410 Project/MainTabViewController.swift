//
//  MainTabViewController.swift
//  410 Project
//
//  Created by İbrahim KARALI on 17.05.2018.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit
import CoreData

class MainTabViewController: UITabBarController {

    @IBAction func logout(_ sender: Any) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate // UIApplication.shared().delegate as! AppDelegate is now UIApplication.shared.delegate as! AppDelegate
        
        
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        
        do {
            
            let results = try context.fetch(request)
            
            if results.count > 0 {
                
                for result in results as! [NSManagedObject] {
                    
                    context.delete(result)
                    
                    do {
                        
                        try context.save()
                        performSegue(withIdentifier: "loginAgain", sender: self)
                        
                    } catch {
                        
                        print("Individual delete failed")
                        
                    }
                    
                }
                
            }
            
        } catch {
            
            print("Delete failed")
            
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
