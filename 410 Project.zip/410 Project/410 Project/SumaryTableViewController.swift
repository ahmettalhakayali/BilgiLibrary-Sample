//
//  SumaryTableViewController.swift
//  410 Project
//
//  Created by İbrahim KARALI on 20.05.2018.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit
import CoreData

class SumaryTableViewController: UITableViewController {
    
    let book = Book.init()
    var books:[Book] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewDidAppear(_ animated: Bool) {
        books = []
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        
        do {
            let results = try context.fetch(request)
            
            if results.count > 0 {
                for result in results as! [NSManagedObject] {
                    let bookNames = result.value(forKey: "books") as! String
                    let myBookList = bookNames.components(separatedBy: ",")
                    for bookName in myBookList {
                        if book.bookList[bookName] != nil {
                            books.append(book.bookList[bookName]!)
                        }
                    }
                }
            }
            tableView.reloadData()
            
        } catch  {
            print("sumcontroller error")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 3
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if section == 0 {
            return books.count
        } else {
            return 1
        }
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "sumBooks", for: indexPath) as! SumaryTableViewCell
            let tempBook = books[indexPath.row]
            cell.bookAuthor.text = tempBook.author
            cell.bookImage.image = tempBook.bookCover
            cell.bookKind.text = tempBook.kind
            cell.bookName.text = tempBook.name
            cell.bookPrice.text = String(describing: tempBook.price)
            return cell
        }
        if indexPath.section == 2 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "infoCell", for: indexPath) as! InfoTableViewCell
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            
            let context = appDelegate.persistentContainer.viewContext
            
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
            
            do {
                let results = try context.fetch(request)
                
                if results.count > 0 {
                    for result in results as! [NSManagedObject] {
                        cell.addressText.text = result.value(forKey: "address") as! String
                        cell.nameField.text = result.value(forKey: "name") as? String
                        cell.emailField.text = result.value(forKey: "email") as? String
                        cell.phoneField.text = result.value(forKey: "phoneNumber") as? String
                    }
                }
                //tableView.reloadData()
                
            } catch  {
                print("sumcontroller error")
            }
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "totalPrice", for: indexPath) as! TotalPriceTableViewCell
            
            var totalPrice = 0.0
            for book in books {
                totalPrice = totalPrice + book.price
            }
            
            cell.totalPriceLabel.text = "\(totalPrice)"
            
            return cell
        }
        

    }
 

}
