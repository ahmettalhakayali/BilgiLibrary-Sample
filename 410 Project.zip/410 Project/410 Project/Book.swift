//
//  Book.swift
//  410 Project
//
//  Created by İbrahim KARALI on 17.05.2018.
//  Copyright © 2018 Student. All rights reserved.
//

import UIKit

class Book: NSObject {
    var name: String
    var author: String
    var price: Double
    var kind: String
    var bookCover: UIImage
    
    
    var bookList: [String:Book]
    var bookKeys: [String]
    
    
    init(name:String, author:String, price:Double, kind:String,bookCover:UIImage) {
        self.name = name
        self.author = author
        self.price = price
        self.kind = kind
        self.bookCover = bookCover
        
        bookList = [:]
        bookKeys = [""]
        
    }
    
    override init() {
        self.name = " "
        self.author = " "
        self.price = 0.0
        self.kind = " "
        self.bookCover = #imageLiteral(resourceName: "defaultBook")
        
        bookList = [
            "Redshirts":Book.init(name: "Redshisrts", author: "John Scalzi", price: 30.0, kind: "Sci-Fi", bookCover: #imageLiteral(resourceName: "redshirts"))
            ,"Lord of The Rings 1":Book.init(name: "Lord of The Rings 1", author: "JRR Tolkien", price: 25.9, kind: "Fantastic",bookCover: #imageLiteral(resourceName: "lotr1")),
                    "Harry Potter 1":Book.init(name: "Harry Potter 1", author: "JK Rowling", price: 23.9, kind: "Fantastic",bookCover: #imageLiteral(resourceName: "hp1")),
                    "Theory of Everything":Book.init(name: "Theory of Everything", author: "Stephan Hawking", price: 14.9, kind: "Science",bookCover: #imageLiteral(resourceName: "theoryofeverything")),
                    "Od":Book.init(name: "Od", author: "Iskender Pala", price: 20.0, kind: "History",bookCover : #imageLiteral(resourceName: "defaultBook") ),
                    "Civil War at Sea":Book.init(name: "Civil War at Sea", author: "Craig L. Symonds" , price: 32.0, kind: "History", bookCover: #imageLiteral(resourceName: "civilwar")),
                    "Burning Up":Book.init(name: "Burning Up", author: "Jannifer Blackwood", price: 10.0, kind: "romance", bookCover: #imageLiteral(resourceName: "burningup"))]
        
        bookKeys = ["Lord of The Rings 1",
                    "Harry Potter 1",
                    "Theory of Everything","Od","Civil War at Sea","Burning Up","Redshirts"]

    }
    
    func filter(byKind: String) -> [Book] {
        let kinds = byKind.components(separatedBy: ",")
        
        var temp: [Book] = []
        for kind in kinds {
            for key in bookKeys {
                let tempBook = bookList[key]
                if tempBook!.kind == kind {
                    temp.append(tempBook!)
                }
            }
        }
        
        return temp
    }
    
    
}
